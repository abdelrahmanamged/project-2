================================================================================
VOLE MACHINE SIMULATOR - QT WIDGETS GUI WRAPPER (TASK 3 BONUS)
================================================================================

This project provides a complete Qt C++ GUI wrapper using Qt Widgets for your 
existing Vole (Brookshear) Machine core engine.

--------------------------------------------------------------------------------
1. PROJECT FEATURES & REQUIREMENTS FULFILLED
--------------------------------------------------------------------------------
✓ Starting Memory Address Specification:
  - Added Hex QSpinBox (startAddressSpinBox) right next to the "Load File" button.
  - Range: 0 to 254 (0x00 to 0xFE), Step = 2 (even addresses).
  - Formatted in clean uppercase hexadecimal (0x00, 0x02, ..., 0xFE).
  - In onLoadFileClicked():
      * Reads the chosen starting address from the spinbox.
      * Passes it to the program loader (e.g. loader.setAddress(startingAddress))
        instead of calling validaddress() via cin.
      * Loads the instructions into memory starting from that address.
      * Updates the CPU Program Counter (machine.setPC(startingAddress) / 
        CPU.setPC(startingAddress)) so execution starts from the chosen cell.
      * Automatically refreshes the UI and highlights the new PC in memory!

✓ Zero Modification Guarantee:
  - Your existing engine classes (Machine.h, Machine.cpp, etc.) remain untouched.
  - Interacts exclusively via clean public accessors.

✓ Main Memory Display:
  - Complete 256 bytes displayed in a 16x16 grid using QTableWidget.
  - Rows labeled 00 to F0, columns labeled +0 to +F.
  - Active Program Counter (PC) address highlighted in gold/amber.
  - Operand byte (PC+1) highlighted in light cyan.
  - Screen Memory Address (0xFF) marked with a distinct mint green badge.
  - Double-click any memory cell to directly edit its hex byte value!

✓ CPU Registers Display:
  - All 16 registers (R0 to RF) shown in a clean QTableWidget.
  - Shows Register Name, Hex value, Decimal value, and ASCII character.

✓ CPU State Display:
  - Program Counter (PC): in Hex and Decimal.
  - Instruction Register (IR): 16-bit hex code.
  - Real-time Opcode Decoder: translates hex instructions into English 
    (e.g., "1128: LOAD R1 from Mem[0x28]").
  - Halted / Ready / Running status badge.
  - Step counter showing total executed instructions.

✓ Screen Display (Connected to Memory Address 0xFF):
  - CRT styled terminal output box.
  - When memory address 0xFF is written or updated, characters/bytes are
    immediately output to the screen display.
  - Includes "Clear Screen" button.

✓ Execution Controls:
  - "Load File...": Opens file chooser to load .txt / .vole / .asm programs.
  - "Start:" Hex QSpinBox: specifies starting memory address.
  - "Run": Continuously executes instructions until C000 HALT.
  - "Single Step": Executes one 2-byte instruction and refreshes UI.
  - "Reset": Resets CPU registers and Main Memory back to initial zero state.
  - Run Speed slider: Adjust execution delay from 10 ms to 500 ms.

--------------------------------------------------------------------------------
2. HOW TO BUILD AND RUN IN QT CREATOR
--------------------------------------------------------------------------------

Option A: Using qmake (Recommended / Standard)
-----------------------------------------------
1. Copy all project files into a single directory:
   - MainWindow.h
   - MainWindow.cpp
   - main.cpp
   - VoleSimulator.pro
   - Your existing engine files (e.g. Machine.h, Machine.cpp, CPU.h, Memory.h)

2. Open Qt Creator:
   - Click "Open Project" (or File -> Open File or Project...)
   - Select the "VoleSimulator.pro" file.

3. Configure Project:
   - Select your Qt Kit (Qt 5.15+ or Qt 6.x with MinGW / MSVC / Clang / GCC).
   - Click "Configure Project".

4. Build and Run:
   - Press the Green Run button (or press Ctrl + R).
   - The GUI window will open immediately!

Option B: Using CMake
-----------------------------------------------
1. If your Qt Creator or IDE uses CMake, open the "CMakeLists.txt" file provided.
2. Select your Desktop Kit and click Run.

--------------------------------------------------------------------------------
3. CONNECTING YOUR EXISTING ENGINE (ZERO MODIFICATIONS NEEDED)
--------------------------------------------------------------------------------
The GUI wrapper interacts with your Vole Machine engine through standard methods:
- machine.reset()
- machine.setPC(startingAddress)
- machine.step()
- machine.isHalted()
- machine.getPC()
- machine.getIR()
- machine.getStepCount()
- machine.getRegister(i)
- machine.getMemoryCell(addr)
- machine.setMemoryCell(addr, value)
- machine.loadProgramFromText(content, startAddress)

If your existing engine class has slightly different method names (e.g. 
"loader.setAddress(startingAddress)" or "CPU.setPC(startingAddress)"), 
simply replace the respective one-line calls in MainWindow.cpp.

--------------------------------------------------------------------------------
4. KEYBOARD SHORTCUTS
--------------------------------------------------------------------------------
- Ctrl + O : Load Program File
- F5       : Run (Full Execution) / Pause
- F10      : Single Step
- F2       : Reset Machine

================================================================================
