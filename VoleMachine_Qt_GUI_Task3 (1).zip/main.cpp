/**
 * ============================================================================
 * Project: Vole Machine Simulator - Qt Widgets GUI (Task 3 Bonus)
 * File:    main.cpp
 * Description: Application entry point. Initializes QApplication with Fusion
 *              modern theme and launches MainWindow.
 * ============================================================================
 */

#include "MainWindow.h"
#include <QApplication>
#include <QStyleFactory>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.setApplicationName("Vole Machine Simulator");
    app.setApplicationVersion("2.0.0");
    app.setOrganizationName("Computer Science Department");

    // Clean, modern Fusion desktop styling
    app.setStyle(QStyleFactory::create("Fusion"));

    MainWindow window;
    window.show();

    return app.exec();
}
