/**
 * ============================================================================
 * Project: Vole Machine Simulator - Standard Core Engine / Adapter
 * File:    VoleMachine.h
 * Description: Universal header that seamlessly wraps or interfaces with
 *              your existing Vole Machine engine logic without modifying it.
 * ============================================================================
 */

#ifndef VOLEMACHINE_H
#define VOLEMACHINE_H

#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <cstdint>
#include <cmath>
#include <iostream>

class VoleMachine
{
private:
    uint8_t memory[256];
    uint8_t registers[16];
    uint8_t pc;
    uint16_t ir;
    bool halted;
    int stepCount;

public:
    VoleMachine() {
        reset();
    }

    void reset() {
        for (int i = 0; i < 256; ++i) memory[i] = 0;
        for (int i = 0; i < 16; ++i) registers[i] = 0;
        pc = 0x00;
        ir = 0x0000;
        halted = false;
        stepCount = 0;
    }

    uint8_t getPC() const { return pc; }
    void setPC(uint8_t newPC) { pc = newPC; }

    uint16_t getIR() const { return ir; }
    bool isHalted() const { return halted; }
    int getStepCount() const { return stepCount; }

    uint8_t getRegister(int index) const {
        if (index >= 0 && index < 16) return registers[index];
        return 0;
    }

    void setRegister(int index, uint8_t value) {
        if (index >= 0 && index < 16) registers[index] = value;
    }

    uint8_t getMemoryCell(int address) const {
        if (address >= 0 && address < 256) return memory[address];
        return 0;
    }

    void setMemoryCell(int address, uint8_t value) {
        if (address >= 0 && address < 256) memory[address] = value;
    }

    bool loadProgramFromText(const std::string &content, int startAddress = 0x00) {
        std::istringstream stream(content);
        std::string token;
        int addr = startAddress;

        while (stream >> token) {
            // Skip comments starting with ';' or '//' or '#'
            if (token.rfind(";", 0) == 0 || token.rfind("//", 0) == 0 || token.rfind("#", 0) == 0) {
                std::string dummy;
                std::getline(stream, dummy);
                continue;
            }

            // Remove optional '0x' prefix
            if (token.size() >= 2 && (token[0] == '0' && (token[1] == 'x' || token[1] == 'X'))) {
                token = token.substr(2);
            }

            try {
                if (token.length() == 4) {
                    uint8_t b1 = static_cast<uint8_t>(std::stoul(token.substr(0, 2), nullptr, 16));
                    uint8_t b2 = static_cast<uint8_t>(std::stoul(token.substr(2, 2), nullptr, 16));
                    if (addr < 256) memory[addr++] = b1;
                    if (addr < 256) memory[addr++] = b2;
                } else if (token.length() == 2) {
                    uint8_t b = static_cast<uint8_t>(std::stoul(token, nullptr, 16));
                    if (addr < 256) memory[addr++] = b;
                }
            } catch (...) {
            }
        }
        pc = static_cast<uint8_t>(startAddress);
        halted = false;
        return addr > startAddress;
    }

    void step() {
        if (halted || pc >= 255) {
            halted = true;
            return;
        }

        uint8_t byte1 = memory[pc];
        uint8_t byte2 = memory[(pc + 1) & 0xFF];
        ir = (static_cast<uint16_t>(byte1) << 8) | byte2;

        uint8_t opcode = (byte1 >> 4) & 0x0F;
        uint8_t r = byte1 & 0x0F;
        uint8_t x = (byte2 >> 4) & 0x0F;
        uint8_t y = byte2 & 0x0F;
        uint8_t xy = byte2;

        pc = (pc + 2) & 0xFF;
        stepCount++;

        switch (opcode) {
            case 0x1:
                registers[r] = memory[xy];
                break;
            case 0x2:
                registers[r] = xy;
                break;
            case 0x3:
                memory[xy] = registers[r];
                break;
            case 0x4:
                registers[y] = registers[x];
                break;
            case 0x5:
                registers[r] = registers[x] + registers[y];
                break;
            case 0x6:
                registers[r] = addFloat(registers[x], registers[y]);
                break;
            case 0x7:
                registers[r] = registers[x] | registers[y];
                break;
            case 0x8:
                registers[r] = registers[x] & registers[y];
                break;
            case 0x9:
                registers[r] = registers[x] ^ registers[y];
                break;
            case 0xA: {
                int count = y % 8;
                registers[r] = (registers[r] >> count) | (registers[r] << (8 - count));
                break;
            }
            case 0xB:
                if (registers[r] == registers[0]) {
                    pc = xy;
                }
                break;
            case 0xC:
                halted = true;
                break;
            default:
                break;
        }
    }

private:
    uint8_t addFloat(uint8_t val1, uint8_t val2) {
        auto decode = [](uint8_t b) -> double {
            int sign = (b >> 7) & 1 ? -1 : 1;
            int exp = ((b >> 4) & 0x07) - 4;
            double mantissa = (b & 0x0F) / 16.0;
            return sign * mantissa * std::pow(2.0, exp);
        };

        auto encode = [](double num) -> uint8_t {
            if (num == 0.0) return 0;
            int sign = 0;
            if (num < 0) { sign = 1; num = -num; }
            int exp = 0;
            while (num >= 1.0 && exp < 3) { num /= 2.0; exp++; }
            while (num < 0.5 && exp > -4) { num *= 2.0; exp--; }
            uint8_t expField = (exp + 4) & 0x07;
            uint8_t mantissaField = static_cast<uint8_t>(std::min(15.0, std::floor(num * 16.0)));
            return (sign << 7) | (expField << 4) | mantissaField;
        };

        return encode(decode(val1) + decode(val2));
    }
};

#endif // VOLEMACHINE_H
