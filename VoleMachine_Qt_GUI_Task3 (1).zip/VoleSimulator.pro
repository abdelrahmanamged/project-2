# ==============================================================================
# Vole Machine Simulator - Qt Project File (qmake)
# Task 3 Bonus - Qt GUI Wrapper
# ==============================================================================

QT       += core gui widgets

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

TARGET = VoleSimulator
TEMPLATE = app

# Source and Header files
SOURCES += \
    main.cpp \
    MainWindow.cpp

HEADERS += \
    MainWindow.h \
    VoleMachine.h
