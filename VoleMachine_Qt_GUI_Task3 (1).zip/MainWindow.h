/**
 * ============================================================================
 * Project: Vole Machine Simulator - Qt Widgets GUI (Task 3 Bonus)
 * File:    MainWindow.h
 * Description: Header file for the main application window displaying
 *              16x16 Main Memory, R0-RF Registers, CPU State (PC, IR, Halt),
 *              Screen Display (Memory mapped to 0xFF), and execution controls.
 *              Includes Hex QSpinBox for customizable starting memory address.
 * ============================================================================
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QTextEdit>
#include <QTimer>
#include <QSlider>
#include <QSpinBox>
#include <QFileDialog>
#include <QMessageBox>
#include <QHeaderView>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QFont>
#include <QFontDatabase>

// Include your existing Vole engine header
#if __has_include("VoleMachine.h")
    #include "VoleMachine.h"
#elif __has_include("Machine.h")
    #include "Machine.h"
#elif __has_include("VoleSimulator.h")
    #include "VoleSimulator.h"
#else
    #include "VoleMachine.h"
#endif

/**
 * Custom QSpinBox displaying values in 2-digit uppercase Hex (0x00, 0x02, 0x10, etc.)
 * Range: 0 to 254 (0x00 to 0xFE), Step = 2 (even addresses).
 */
class HexSpinBox : public QSpinBox
{
    Q_OBJECT
public:
    explicit HexSpinBox(QWidget *parent = nullptr) : QSpinBox(parent)
    {
        setRange(0, 254);
        setSingleStep(2);
        setDisplayIntegerBase(16);
    }

protected:
    QString textFromValue(int val) const override
    {
        return QString("0x%1").arg(QString::number(val, 16).rightJustified(2, '0').toUpper());
    }

    int valueFromText(const QString &text) const override
    {
        QString clean = text;
        clean.remove("0x", Qt::CaseInsensitive);
        bool ok;
        int val = clean.toInt(&ok, 16);
        return ok ? val : 0;
    }
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onLoadFileClicked();
    void onRunClicked();
    void onStepClicked();
    void onResetClicked();
    void onClearScreenClicked();
    void onTimerTick();
    void onSpeedSliderChanged(int value);
    void onMemoryCellDoubleClicked(int row, int col);
    void onStartAddressChanged(int value);

private:
    // Core Engine Instance (Keep your existing engine logic untouched)
    // If your class is named Machine, change VoleMachine to Machine here:
    VoleMachine machine;

    // Execution Timer for animated "Run" mode
    QTimer *runTimer;
    bool isRunningContinuous;

    // UI Components - Main Memory (16x16 = 256 bytes)
    QTableWidget *memoryTable;

    // UI Components - CPU Registers (R0 - RF)
    QTableWidget *registerTable;

    // UI Components - CPU State
    QLabel *pcValueLabel;
    QLabel *irValueLabel;
    QLabel *irDecodedLabel;
    QLabel *statusBadgeLabel;
    QLabel *stepCountLabel;

    // UI Components - Screen Display (Connected to 0xFF)
    QTextEdit *screenDisplay;
    QLabel *screenByteLabel;

    // UI Components - Controls & Starting Address
    QPushButton *btnLoadFile;
    HexSpinBox *startAddressSpinBox;
    QPushButton *btnRun;
    QPushButton *btnStep;
    QPushButton *btnReset;
    QPushButton *btnClearScreen;
    QSlider *speedSlider;
    QLabel *speedLabel;

    // Tracking variables for Screen output and PC highlight
    int lastScreenByteValue;
    int previousPcAddress;

    // Setup and UI update methods
    void setupUI();
    void setupStyles();
    void setupMemoryTable();
    void setupRegisterTable();
    void setupCpuStatePanel(QGroupBox *box);
    void setupScreenPanel(QGroupBox *box);
    void setupControlsPanel(QGroupBox *box);

    // Refresh UI after step/run/reset
    void updateUI();
    void highlightMemoryPC(int currentPC);
    void syncScreenDisplay();
    QString decodeInstruction(int opcode, int r, int x, int y);
};

#endif // MAINWINDOW_H
