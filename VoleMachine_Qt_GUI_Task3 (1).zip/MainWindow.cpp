/**
 * ============================================================================
 * Project: Vole Machine Simulator - Qt Widgets GUI (Task 3 Bonus)
 * File:    MainWindow.cpp
 * Description: Complete implementation of Qt Widgets GUI for Vole Machine.
 *              Includes starting memory address QSpinBox (0x00 - 0xFE, Step 2),
 *              16x16 Memory grid, R0-RF registers, CPU state, 0xFF Screen port.
 * ============================================================================
 */
#include <QRegularExpression>
#include "MainWindow.h"
#include <QApplication>
#include <QFile>
#include <QTextStream>
#include <QInputDialog>
#include <QSplitter>
#include <QStatusBar>
#include <QToolBar>
#include <iomanip>
#include <sstream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      isRunningContinuous(false),
      lastScreenByteValue(0),
      previousPcAddress(-1)
{
    setWindowTitle("Vole Machine Simulator - Qt GUI (Task 3 Bonus)");
    resize(1200, 800);
    setMinimumSize(1000, 700);

    // Execution timer for smooth continuous running
    runTimer = new QTimer(this);
    connect(runTimer, &QTimer::timeout, this, &MainWindow::onTimerTick);

    setupUI();
    setupStyles();

    // Initial sync
    updateUI();
    statusBar()->showMessage("System ready. Choose starting address, load a file, or use Single Step.");
}

MainWindow::~MainWindow()
{
    if (runTimer->isActive()) {
        runTimer->stop();
    }
}

void MainWindow::setupUI()
{
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QHBoxLayout *mainLayout = new QHBoxLayout(centralWidget);
    mainLayout->setContentsMargins(12, 12, 12, 12);
    mainLayout->setSpacing(12);

    // =========================================================================
    // LEFT PANEL: Controls, CPU State, Registers, and Screen Display (0xFF)
    // =========================================================================
    QWidget *leftPanel = new QWidget(this);
    QVBoxLayout *leftLayout = new QVBoxLayout(leftPanel);
    leftLayout->setContentsMargins(0, 0, 0, 0);
    leftLayout->setSpacing(10);

    // 1. Controls Group
    QGroupBox *controlsBox = new QGroupBox("Execution Controls", this);
    setupControlsPanel(controlsBox);
    leftLayout->addWidget(controlsBox);

    // 2. CPU State Group
    QGroupBox *cpuBox = new QGroupBox("CPU State & Registers", this);
    setupCpuStatePanel(cpuBox);
    leftLayout->addWidget(cpuBox);

    // 3. Screen Display Group (Connected to 0xFF)
    QGroupBox *screenBox = new QGroupBox("Screen Display (Port 0xFF)", this);
    setupScreenPanel(screenBox);
    leftLayout->addWidget(screenBox);

    leftPanel->setMaximumWidth(480);
    leftPanel->setMinimumWidth(390);

    // =========================================================================
    // RIGHT PANEL: Main Memory (16x16 Grid = 256 Bytes)
    // =========================================================================
    QGroupBox *memoryBox = new QGroupBox("Main Memory (256 Bytes / 16x16 Grid)", this);
    QVBoxLayout *memoryLayout = new QVBoxLayout(memoryBox);
    memoryLayout->setContentsMargins(10, 15, 10, 10);

    QLabel *memLegend = new QLabel(
        "<b>Legend:</b> <span style='background-color:#ffe082; color:#000; padding:2px 6px; border-radius:3px;'><b>PC (Current)</b></span> "
        "<span style='background-color:#b2ebf2; color:#000; padding:2px 6px; border-radius:3px;'><b>PC+1 (Operand)</b></span> "
        "<span style='background-color:#c8e6c9; color:#000; padding:2px 6px; border-radius:3px;'><b>0xFF (Screen)</b></span> "
        "<i>(Double-click any cell to edit hex value)</i>", this);
    memLegend->setTextFormat(Qt::RichText);
    memoryLayout->addWidget(memLegend);

    setupMemoryTable();
    memoryLayout->addWidget(memoryTable);

    // Add Left and Right panels to Main Layout
    mainLayout->addWidget(leftPanel);
    mainLayout->addWidget(memoryBox, 1);
}

void MainWindow::setupControlsPanel(QGroupBox *box)
{
    QVBoxLayout *boxLayout = new QVBoxLayout(box);
    boxLayout->setSpacing(8);

    // =========================================================================
    // Row 1: Load File, Starting Memory Address QSpinBox, and Reset
    // =========================================================================
    QHBoxLayout *btnRow1 = new QHBoxLayout();
    btnRow1->setSpacing(6);

    btnLoadFile = new QPushButton("📂 Load File...", this);
    btnLoadFile->setToolTip("Load instructions from a text file (Ctrl+O)");
    btnLoadFile->setShortcut(QKeySequence::Open);

    // Starting Address Label + Hex QSpinBox (0 to 254, step 2, base 16)
    QLabel *lblStartAddr = new QLabel("Start:", this);
    lblStartAddr->setToolTip("Starting memory address (0x00 - 0xFE, step 2)");

    startAddressSpinBox = new HexSpinBox(this);
    startAddressSpinBox->setRange(0, 254);
    startAddressSpinBox->setSingleStep(2);
    startAddressSpinBox->setValue(0);
    startAddressSpinBox->setMinimumWidth(82);
    startAddressSpinBox->setFont(QFont("Monospace", 9, QFont::Bold));
    startAddressSpinBox->setToolTip("Choose starting memory address (0x00 to 0xFE, step = 2)");

    btnReset = new QPushButton("🔄 Reset", this);
    btnReset->setToolTip("Reset CPU and Main Memory (F2)");
    btnReset->setShortcut(QKeySequence(Qt::Key_F2));

    btnRow1->addWidget(btnLoadFile);
    btnRow1->addWidget(lblStartAddr);
    btnRow1->addWidget(startAddressSpinBox);
    btnRow1->addWidget(btnReset);
    boxLayout->addLayout(btnRow1);

    // =========================================================================
    // Row 2: Single Step & Run/Pause Buttons
    // =========================================================================
    QHBoxLayout *btnRow2 = new QHBoxLayout();
    btnStep = new QPushButton("▶ Single Step", this);
    btnStep->setToolTip("Execute next instruction (F10)");
    btnStep->setShortcut(QKeySequence(Qt::Key_F10));
    btnStep->setStyleSheet("font-weight: bold; background-color: #2196F3; color: white;");

    btnRun = new QPushButton("⏩ Run", this);
    btnRun->setToolTip("Run continuously until HALT (F5)");
    btnRun->setShortcut(QKeySequence(Qt::Key_F5));
    btnRun->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");

    btnRow2->addWidget(btnStep);
    btnRow2->addWidget(btnRun);
    boxLayout->addLayout(btnRow2);

    // =========================================================================
    // Row 3: Run Speed Slider
    // =========================================================================
    QHBoxLayout *speedLayout = new QHBoxLayout();
    QLabel *speedTitle = new QLabel("Run Speed:", this);
    speedSlider = new QSlider(Qt::Horizontal, this);
    speedSlider->setRange(10, 500);
    speedSlider->setValue(100);
    speedSlider->setInvertedAppearance(true);
    speedLabel = new QLabel("100 ms", this);
    speedLabel->setMinimumWidth(55);

    speedLayout->addWidget(speedTitle);
    speedLayout->addWidget(speedSlider);
    speedLayout->addWidget(speedLabel);
    boxLayout->addLayout(speedLayout);

    // Connect signals
    connect(btnLoadFile, &QPushButton::clicked, this, &MainWindow::onLoadFileClicked);
    connect(btnRun, &QPushButton::clicked, this, &MainWindow::onRunClicked);
    connect(btnStep, &QPushButton::clicked, this, &MainWindow::onStepClicked);
    connect(btnReset, &QPushButton::clicked, this, &MainWindow::onResetClicked);
    connect(speedSlider, &QSlider::valueChanged, this, &MainWindow::onSpeedSliderChanged);
    connect(startAddressSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::onStartAddressChanged);
}

void MainWindow::setupCpuStatePanel(QGroupBox *box)
{
    QVBoxLayout *boxLayout = new QVBoxLayout(box);
    boxLayout->setSpacing(8);

    QGridLayout *statusGrid = new QGridLayout();
    statusGrid->setSpacing(6);

    QLabel *lblPC = new QLabel("<b>Program Counter (PC):</b>", this);
    pcValueLabel = new QLabel("0x00 (0)", this);
    pcValueLabel->setStyleSheet("font-family: monospace; font-size: 13px; font-weight: bold; color: #1565C0;");

    QLabel *lblIR = new QLabel("<b>Instruction (IR):</b>", this);
    irValueLabel = new QLabel("0x0000", this);
    irValueLabel->setStyleSheet("font-family: monospace; font-size: 13px; font-weight: bold; color: #D84315;");

    QLabel *lblStatus = new QLabel("<b>CPU Status:</b>", this);
    statusBadgeLabel = new QLabel("READY", this);
    statusBadgeLabel->setAlignment(Qt::AlignCenter);
    statusBadgeLabel->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white; border-radius: 4px; padding: 2px 8px;");

    QLabel *lblSteps = new QLabel("<b>Step Count:</b>", this);
    stepCountLabel = new QLabel("0", this);

    statusGrid->addWidget(lblPC, 0, 0);
    statusGrid->addWidget(pcValueLabel, 0, 1);
    statusGrid->addWidget(lblIR, 1, 0);
    statusGrid->addWidget(irValueLabel, 1, 1);
    statusGrid->addWidget(lblStatus, 2, 0);
    statusGrid->addWidget(statusBadgeLabel, 2, 1);
    statusGrid->addWidget(lblSteps, 3, 0);
    statusGrid->addWidget(stepCountLabel, 3, 1);

    boxLayout->addLayout(statusGrid);

    irDecodedLabel = new QLabel("<i>No instruction executed yet</i>", this);
    irDecodedLabel->setWordWrap(true);
    irDecodedLabel->setStyleSheet("background-color: #f5f5f5; border: 1px solid #ddd; border-radius: 4px; padding: 4px 8px; font-size: 11px;");
    boxLayout->addWidget(irDecodedLabel);

    QLabel *regTitle = new QLabel("<b>General-Purpose Registers (R0 - RF):</b>", this);
    boxLayout->addWidget(regTitle);

    setupRegisterTable();
    boxLayout->addWidget(registerTable);
}

void MainWindow::setupRegisterTable()
{
    registerTable = new QTableWidget(16, 4, this);
    QStringList headers;
    headers << "Reg" << "Hex" << "Decimal" << "ASCII";
    registerTable->setHorizontalHeaderLabels(headers);
    registerTable->verticalHeader()->setVisible(false);
    registerTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    registerTable->setSelectionMode(QAbstractItemView::SingleSelection);
    registerTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    registerTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    registerTable->setMaximumHeight(180);

    for (int i = 0; i < 16; ++i) {
        QString regName = QString("R%1").arg(QString::number(i, 16).toUpper());
        QTableWidgetItem *itemReg = new QTableWidgetItem(regName);
        itemReg->setTextAlignment(Qt::AlignCenter);
        itemReg->setFont(QFont("Monospace", 9, QFont::Bold));

        QTableWidgetItem *itemHex = new QTableWidgetItem("00");
        itemHex->setTextAlignment(Qt::AlignCenter);
        itemHex->setFont(QFont("Monospace", 9));

        QTableWidgetItem *itemDec = new QTableWidgetItem("0");
        itemDec->setTextAlignment(Qt::AlignCenter);

        QTableWidgetItem *itemAscii = new QTableWidgetItem(".");
        itemAscii->setTextAlignment(Qt::AlignCenter);

        registerTable->setItem(i, 0, itemReg);
        registerTable->setItem(i, 1, itemHex);
        registerTable->setItem(i, 2, itemDec);
        registerTable->setItem(i, 3, itemAscii);
        registerTable->setRowHeight(i, 22);
    }
}

void MainWindow::setupScreenPanel(QGroupBox *box)
{
    QVBoxLayout *boxLayout = new QVBoxLayout(box);
    boxLayout->setSpacing(6);

    QHBoxLayout *topRow = new QHBoxLayout();
    screenByteLabel = new QLabel("<b>Port 0xFF Value:</b> 0x00 (ASCII: '.')", this);
    btnClearScreen = new QPushButton("Clear Screen", this);
    btnClearScreen->setMaximumWidth(100);
    topRow->addWidget(screenByteLabel);
    topRow->addWidget(btnClearScreen);
    boxLayout->addLayout(topRow);

    screenDisplay = new QTextEdit(this);
    screenDisplay->setReadOnly(true);
    screenDisplay->setFont(QFont("Consolas", 11));
    screenDisplay->setStyleSheet(
        "background-color: #121212; color: #00FF66; border: 1px solid #333; "
        "border-radius: 4px; padding: 6px; font-family: 'Consolas', 'Courier New', monospace;"
    );
    screenDisplay->setMinimumHeight(110);
    screenDisplay->setMaximumHeight(160);
    screenDisplay->setPlaceholderText("[Screen Output Port 0xFF] Written text will appear here...");

    boxLayout->addWidget(screenDisplay);

    connect(btnClearScreen, &QPushButton::clicked, this, &MainWindow::onClearScreenClicked);
}

void MainWindow::setupMemoryTable()
{
    // 16 rows x 16 columns = 256 memory locations (0x00 to 0xFF)
    memoryTable = new QTableWidget(16, 16, this);

    QStringList colHeaders;
    for (int col = 0; col < 16; ++col) {
        colHeaders << QString("+%1").arg(QString::number(col, 16).toUpper());
    }
    memoryTable->setHorizontalHeaderLabels(colHeaders);

    QStringList rowHeaders;
    for (int row = 0; row < 16; ++row) {
        rowHeaders << QString("%10").arg(QString::number(row, 16).toUpper());
    }
    memoryTable->setVerticalHeaderLabels(rowHeaders);

    QFont monoFont("Monospace", 9);

    for (int r = 0; r < 16; ++r) {
        memoryTable->setRowHeight(r, 26);
        for (int c = 0; c < 16; ++c) {
            QTableWidgetItem *item = new QTableWidgetItem("00");
            item->setTextAlignment(Qt::AlignCenter);
            item->setFont(monoFont);
            
            // Mark screen memory cell 0xFF (Row 15, Col 15)
            if (r == 15 && c == 15) {
                item->setBackground(QBrush(QColor("#c8e6c9")));
                item->setToolTip("Memory 0xFF: Screen Display Output Port");
            } else {
                item->setToolTip(QString("Address: 0x%1%2")
                                     .arg(QString::number(r, 16).toUpper())
                                     .arg(QString::number(c, 16).toUpper()));
            }
            memoryTable->setItem(r, c, item);
        }
    }

    memoryTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    memoryTable->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    connect(memoryTable, &QTableWidget::cellDoubleClicked, this, &MainWindow::onMemoryCellDoubleClicked);
}

void MainWindow::setupStyles()
{
    setStyleSheet(
        "QMainWindow { background-color: #f7f9fa; }"
        "QGroupBox { font-weight: bold; border: 1px solid #dcdfe6; border-radius: 6px; margin-top: 10px; padding-top: 12px; }"
        "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #2c3e50; }"
        "QPushButton { padding: 6px 12px; border-radius: 4px; border: 1px solid #bbb; background-color: #ffffff; }"
        "QPushButton:hover { background-color: #eef2f7; border-color: #888; }"
        "QPushButton:pressed { background-color: #dde3ea; }"
        "QSpinBox { padding: 4px 6px; border: 1px solid #bbb; border-radius: 4px; background: #fff; font-family: monospace; }"
        "QTableWidget { gridline-color: #e0e0e0; border: 1px solid #ccc; selection-background-color: #bbdefb; }"
        "QHeaderView::section { background-color: #eceff1; font-weight: bold; border: 1px solid #cfd8dc; padding: 2px; }"
    );
}

void MainWindow::onLoadFileClicked()
{
    QString fileName = QFileDialog::getOpenFileName(
        this,
        "Load Vole Program File",
        "",
        "Text / Assembly Files (*.txt *.vole *.asm);;All Files (*.*)"
    );

    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::critical(this, "Error", "Could not open file: " + file.errorString());
        return;
    }

    QTextStream in(&file);
    QString fileContent = in.readAll();
    file.close();

    // =========================================================================
    // 1. Read the selected starting memory address from the QSpinBox
    // =========================================================================
    int startingAddress = startAddressSpinBox->value();

    // Reset machine state
    machine.reset();

    // =========================================================================
    // 2. Pass this address to your program loader and load into memory starting
    //    from that address (e.g. loader.setAddress(startingAddress))
    // =========================================================================
    bool loaded = machine.loadProgramFromText(fileContent.toStdString(), startingAddress);

    if (!loaded) {
        // Fallback: token parser loading sequentially from startingAddress
QStringList tokens = fileContent.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);        int memAddr = startingAddress;
        for (const QString &token : tokens) {
            if (token.startsWith(";") || token.startsWith("//") || token.startsWith("#")) break;
            bool ok;
            int byteVal = token.toInt(&ok, 16);
            if (ok && memAddr < 256) {
                machine.setMemoryCell(memAddr++, byteVal);
            }
        }
    }

    // =========================================================================
    // 3. Update the CPU's Program Counter (CPU.setPC(startingAddress))
    //    so execution starts from the chosen cell
    // =========================================================================
    machine.setPC(static_cast<uint8_t>(startingAddress));

    previousPcAddress = -1;
    lastScreenByteValue = 0;
    screenDisplay->clear();

    // =========================================================================
    // 4. Refresh memory table in UI and highlight the new PC position
    // =========================================================================
    updateUI();

    statusBar()->showMessage(
        QString("Loaded file into memory starting at 0x%1: %2")
            .arg(QString::number(startingAddress, 16).rightJustified(2, '0').toUpper(), fileName),
        4000);
}

void MainWindow::onStartAddressChanged(int value)
{
    // If the machine is ready (not running), sync the PC to the selected start address
    if (!isRunningContinuous && machine.getStepCount() == 0) {
        machine.setPC(static_cast<uint8_t>(value));
        updateUI();
    }
}

void MainWindow::onStepClicked()
{
    if (machine.isHalted()) {
        QMessageBox::information(this, "Halted", "The machine is halted (C000). Click Reset to start again.");
        return;
    }

    machine.step();
    updateUI();
}

void MainWindow::onRunClicked()
{
    if (machine.isHalted()) {
        QMessageBox::information(this, "Halted", "The machine is already halted. Click Reset to run again.");
        return;
    }

    if (isRunningContinuous) {
        isRunningContinuous = false;
        runTimer->stop();
        btnRun->setText("⏩ Run");
        btnRun->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        btnStep->setEnabled(true);
        statusBar()->showMessage("Execution paused.");
    } else {
        isRunningContinuous = true;
        btnRun->setText("⏸ Pause");
        btnRun->setStyleSheet("font-weight: bold; background-color: #FF9800; color: white;");
        btnStep->setEnabled(false);
        runTimer->start(speedSlider->value());
        statusBar()->showMessage("Running program...");
    }
}

void MainWindow::onTimerTick()
{
    if (!machine.isHalted() && isRunningContinuous) {
        machine.step();
        updateUI();

        if (machine.isHalted()) {
            isRunningContinuous = false;
            runTimer->stop();
            btnRun->setText("⏩ Run");
            btnRun->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
            btnStep->setEnabled(true);
            statusBar()->showMessage("Execution halted (C000).", 5000);
        }
    } else {
        runTimer->stop();
        isRunningContinuous = false;
        btnRun->setText("⏩ Run");
        btnRun->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        btnStep->setEnabled(true);
    }
}

void MainWindow::onResetClicked()
{
    if (isRunningContinuous) {
        runTimer->stop();
        isRunningContinuous = false;
        btnRun->setText("⏩ Run");
        btnRun->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white;");
        btnStep->setEnabled(true);
    }

    machine.reset();
    int startAddr = startAddressSpinBox->value();
    machine.setPC(static_cast<uint8_t>(startAddr));

    previousPcAddress = -1;
    lastScreenByteValue = 0;
    screenDisplay->clear();
    updateUI();
    statusBar()->showMessage("Machine reset. PC initialized to starting address.", 3000);
}

void MainWindow::onClearScreenClicked()
{
    screenDisplay->clear();
}

void MainWindow::onSpeedSliderChanged(int value)
{
    speedLabel->setText(QString("%1 ms").arg(value));
    if (runTimer->isActive()) {
        runTimer->setInterval(value);
    }
}

void MainWindow::onMemoryCellDoubleClicked(int row, int col)
{
    int addr = (row * 16) + col;
    int currentVal = machine.getMemoryCell(addr);

    bool ok;
    QString hexStr = QInputDialog::getText(
        this,
        "Edit Memory Cell",
        QString("Enter Hex byte value for address 0x%1:")
            .arg(QString::number(addr, 16).rightJustified(2, '0').toUpper()),
        QLineEdit::Normal,
        QString::number(currentVal, 16).rightJustified(2, '0').toUpper(),
        &ok
    );

    if (ok && !hexStr.isEmpty()) {
        bool convOk;
        int newVal = hexStr.toInt(&convOk, 16);
        if (convOk && newVal >= 0 && newVal <= 0xFF) {
            machine.setMemoryCell(addr, newVal);
            updateUI();
        } else {
            QMessageBox::warning(this, "Invalid Input", "Please enter a valid 2-digit hex value (00 - FF).");
        }
    }
}

void MainWindow::updateUI()
{
    // 1. Refresh 16x16 Memory Grid
    for (int r = 0; r < 16; ++r) {
        for (int c = 0; c < 16; ++c) {
            int addr = (r * 16) + c;
            int val = machine.getMemoryCell(addr) & 0xFF;
            QString hexVal = QString::number(val, 16).rightJustified(2, '0').toUpper();

            QTableWidgetItem *item = memoryTable->item(r, c);
            if (item) {
                item->setText(hexVal);
                if (addr == 0xFF) {
                    item->setBackground(QBrush(QColor("#c8e6c9")));
                } else {
                    item->setBackground(QBrush(QColor("#ffffff")));
                }
            }
        }
    }

    int currentPC = machine.getPC() & 0xFF;
    highlightMemoryPC(currentPC);

    // 2. Refresh CPU State
    pcValueLabel->setText(QString("0x%1 (%2)")
                              .arg(QString::number(currentPC, 16).rightJustified(2, '0').toUpper())
                              .arg(currentPC));

    int ir = machine.getIR() & 0xFFFF;
    irValueLabel->setText(QString("0x%1").arg(QString::number(ir, 16).rightJustified(4, '0').toUpper()));

    int opcode = (ir >> 12) & 0x0F;
    int regR   = (ir >> 8) & 0x0F;
    int opX    = (ir >> 4) & 0x0F;
    int opY    = ir & 0x0F;
    irDecodedLabel->setText(decodeInstruction(opcode, regR, opX, opY));

    if (machine.isHalted()) {
        statusBadgeLabel->setText("HALTED");
        statusBadgeLabel->setStyleSheet("font-weight: bold; background-color: #E53935; color: white; border-radius: 4px; padding: 2px 8px;");
    } else {
        statusBadgeLabel->setText(isRunningContinuous ? "RUNNING" : "READY");
        statusBadgeLabel->setStyleSheet("font-weight: bold; background-color: #4CAF50; color: white; border-radius: 4px; padding: 2px 8px;");
    }

    stepCountLabel->setText(QString::number(machine.getStepCount()));

    // 3. Refresh Registers R0-RF
    for (int i = 0; i < 16; ++i) {
        int regVal = machine.getRegister(i) & 0xFF;
        QString hexVal = QString::number(regVal, 16).rightJustified(2, '0').toUpper();
        QString decVal = QString::number(regVal);
        QChar ch = (regVal >= 32 && regVal <= 126) ? QChar(regVal) : QChar('.');
        QString asciiVal = QString("'%1'").arg(ch);

        if (registerTable->item(i, 1)) registerTable->item(i, 1)->setText(hexVal);
        if (registerTable->item(i, 2)) registerTable->item(i, 2)->setText(decVal);
        if (registerTable->item(i, 3)) registerTable->item(i, 3)->setText(asciiVal);
    }

    // 4. Synchronize Screen Display (Port 0xFF)
    syncScreenDisplay();
}

void MainWindow::highlightMemoryPC(int currentPC)
{
    if (previousPcAddress >= 0 && previousPcAddress < 256) {
        int prevRow = previousPcAddress / 16;
        int prevCol = previousPcAddress % 16;
        QTableWidgetItem *prevItem = memoryTable->item(prevRow, prevCol);
        if (prevItem) {
            prevItem->setBackground(previousPcAddress == 0xFF ? QBrush(QColor("#c8e6c9")) : QBrush(QColor("#ffffff")));
            prevItem->setForeground(QBrush(QColor("#000000")));
        }

        int prevNext = (previousPcAddress + 1) & 0xFF;
        int pNextRow = prevNext / 16;
        int pNextCol = prevNext % 16;
        QTableWidgetItem *pNextItem = memoryTable->item(pNextRow, pNextCol);
        if (pNextItem) {
            pNextItem->setBackground(prevNext == 0xFF ? QBrush(QColor("#c8e6c9")) : QBrush(QColor("#ffffff")));
            pNextItem->setForeground(QBrush(QColor("#000000")));
        }
    }

    // Current PC (Opcode byte) in gold/amber
    int curRow = currentPC / 16;
    int curCol = currentPC % 16;
    QTableWidgetItem *curItem = memoryTable->item(curRow, curCol);
    if (curItem) {
        curItem->setBackground(QBrush(QColor("#ffe082")));
        curItem->setForeground(QBrush(QColor("#b71c1c")));
        curItem->setFont(QFont("Monospace", 9, QFont::Bold));
    }

    // PC+1 (Operand byte) in cyan
    int nextPC = (currentPC + 1) & 0xFF;
    int nextRow = nextPC / 16;
    int nextCol = nextPC % 16;
    QTableWidgetItem *nextItem = memoryTable->item(nextRow, nextCol);
    if (nextItem && nextPC != currentPC) {
        nextItem->setBackground(QBrush(QColor("#b2ebf2")));
        nextItem->setForeground(QBrush(QColor("#004d40")));
        nextItem->setFont(QFont("Monospace", 9, QFont::Bold));
    }

    previousPcAddress = currentPC;
}

void MainWindow::syncScreenDisplay()
{
    int currentScreenVal = machine.getMemoryCell(0xFF) & 0xFF;

    QChar asciiChar = (currentScreenVal >= 32 && currentScreenVal <= 126) ? QChar(currentScreenVal) : QChar('.');
    screenByteLabel->setText(
        QString("<b>Port 0xFF Value:</b> 0x%1 (Dec: %2, ASCII: '%3')")
            .arg(QString::number(currentScreenVal, 16).rightJustified(2, '0').toUpper())
            .arg(currentScreenVal)
            .arg(asciiChar)
    );

    if (currentScreenVal != lastScreenByteValue && currentScreenVal != 0) {
        if (currentScreenVal == 10) {
            screenDisplay->append("");
        } else if (currentScreenVal >= 32 && currentScreenVal <= 126) {
            screenDisplay->insertPlainText(QString(QChar(currentScreenVal)));
        } else {
            screenDisplay->insertPlainText(QString("[0x%1]")
                .arg(QString::number(currentScreenVal, 16).rightJustified(2, '0').toUpper()));
        }

        QTextCursor c = screenDisplay->textCursor();
        c.movePosition(QTextCursor::End);
        screenDisplay->setTextCursor(c);

        lastScreenByteValue = currentScreenVal;
    }
}

QString MainWindow::decodeInstruction(int opcode, int r, int x, int y)
{
    QString rName = QString("R%1").arg(QString::number(r, 16).toUpper());
    int xy = (x << 4) | y;
    QString xyHex = QString::number(xy, 16).rightJustified(2, '0').toUpper();

    switch (opcode) {
        case 0x1:
            return QString("<b>1%1%2%3:</b> LOAD %4 from Mem[0x%5]")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName).arg(xyHex);
        case 0x2:
            return QString("<b>2%1%2%3:</b> LOAD %4 with immediate value 0x%5")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName).arg(xyHex);
        case 0x3:
            if (xy == 0xFF) {
                return QString("<b>3%1FF:</b> STORE %2 to <b>Screen Port [0xFF]</b>")
                    .arg(QString::number(r, 16).toUpper())
                    .arg(rName);
            }
            return QString("<b>3%1%2%3:</b> STORE %4 to Mem[0x%5]")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName).arg(xyHex);
        case 0x4:
            return QString("<b>40%1%2:</b> MOVE R%3 to R%4")
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper());
        case 0x5:
            return QString("<b>5%1%2%3:</b> ADD %4 + R%5 (Two's comp) -> %4")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString("R%1").arg(QString::number(x, 16).toUpper()))
                .arg(QString::number(y, 16).toUpper());
        case 0x6:
            return QString("<b>6%1%2%3:</b> ADD %4 + R%5 (Float) -> %4")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString("R%1").arg(QString::number(x, 16).toUpper()))
                .arg(QString::number(y, 16).toUpper());
        case 0x7:
            return QString("<b>7%1%2%3:</b> OR R%4 | R%5 -> %6")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName);
        case 0x8:
            return QString("<b>8%1%2%3:</b> AND R%4 & R%5 -> %6")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName);
        case 0x9:
            return QString("<b>9%1%2%3:</b> XOR R%4 ^ R%5 -> %6")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName);
        case 0xA:
            return QString("<b>A%10%2:</b> ROTATE %3 right %4 times")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(rName).arg(y);
        case 0xB:
            return QString("<b>B%1%2%3:</b> JUMP to 0x%4 if %5 == R0")
                .arg(QString::number(r, 16).toUpper())
                .arg(QString::number(x, 16).toUpper())
                .arg(QString::number(y, 16).toUpper())
                .arg(xyHex).arg(rName);
        case 0xC:
            return QString("<b>C000:</b> HALT Execution");
        default:
            return QString("Opcode 0x%1 (Address: 0x%2)")
                .arg(QString::number(opcode, 16).toUpper())
                .arg(xyHex);
    }
}
